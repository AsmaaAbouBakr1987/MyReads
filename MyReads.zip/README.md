# MyReads
 a web application that allows you to select and categorize books you have read, are currently reading, or want to read.
